/* SPDX-License-Identifier: GPL-2.0 */
#define DRIVERVERSION	"v5.2.5.2.1_xxxx.20181112_beta"
#define BTCOEXVERSION	"COEX20170310-1212"
